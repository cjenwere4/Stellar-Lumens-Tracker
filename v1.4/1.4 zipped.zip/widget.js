new TradingView.widget(
{
"width": 750,
"height": 500,
"symbol": "BINANCE:XLMUSD",
"interval": "15",
"timezone": "Etc/UTC",
"theme": "Dark",
"style": "1",
"locale": "en",
"toolbar_bg": "rgba(0, 0, 0, 1)",
"enable_publishing": false,
"save_image": false,
"container_id": "tradingview_8ff1c"
});
